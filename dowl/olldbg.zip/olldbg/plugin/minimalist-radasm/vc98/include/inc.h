#include <windows.h>
#include <commdlg.h>
#include <commctrl.h>
#include <ole2.h>
#include <richedit.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <winver.h>

#define _N __declspec (naked)